# VClient (Fabric, Minecraft 26.2)

Java 25, Gradle 9.3+, Fabric Loom без ремаппинга (имена классов — Mojang).

## Сборка
1. Скачай шаблон мода: https://fabricmc.net/develop/template/ (версия 26.2)
   либо возьми оттуда папку `gradle/`, `gradlew`, `gradlew.bat`.
2. Положи их в эту папку рядом с build.gradle.
3. `./gradlew build` -> jar в build/libs/
4. Закинь jar в mods + Fabric API.

## Быстрая сборка (Windows)
Double click build.bat, the jar will be in the out folder.

## Управление
- Right Shift — меню (Огурец Клиент)
- ЛКМ вкл/выкл (для кнопок команд — выполнить), ПКМ настройки, СКМ бинд клавиши
- Zoom: зажми C (стартовый FOV в настройках)
- Конфиг: config/vclient/default.json (команды сервера меняются там, поле "Команда")

## Благодарности
Названия точек подключения миксинов к ItemInHandRenderer для 26.2 сверены с открытым модом
View Model by I-No-oNe (MIT). Код написан заново.
