package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.LivingEntity;

/** Информация о цели, которую ты недавно ударил. */
public class TargetHud extends HudModule {
    public final Setting.Num seconds = add(new Setting.Num("Показывать, сек", 6, 1, 20, 1));

    public TargetHud() { super("TargetHUD", "Имя и здоровье цели", 50, 62); }

    @Override public void onHud(GuiGraphicsExtractor g) {
        LivingEntity t = VClient.lastTarget;
        if (t == null || !t.isAlive()) return;
        if (System.currentTimeMillis() - VClient.lastTargetTime > seconds.get() * 1000) return;
        Minecraft mc = Minecraft.getInstance();
        Font f = mc.font;
        String name = t.getName().getString();
        float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
        String hpTxt = String.format("%.1f / %.0f", hp, max);
        int w = Math.max(130, f.width(name) + 30), h = 40;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        int x = (int) ((sw - w) * posX.get() / 100.0), y = (int) ((sh - h) * posY.get() / 100.0);
        Draw.rrect(g, x, y, w, h, 6, 0xC8101015);
        Draw.rrect(g, x + 8, y + 8, 6, 6, 3, Draw.ACCENT);
        g.text(f, name, x + 19, y + 7, 0xFFFFFFFF);
        g.text(f, hpTxt, x + w - 8 - f.width(hpTxt), y + 7, 0xFFC8C8D0);
        int bw = w - 16;
        Draw.rrect(g, x + 8, y + 24, bw, 8, 4, 0xFF3A3A46);
        float ratio = Math.max(0f, Math.min(1f, hp / max));
        int fw = Math.max(0, (int) (bw * ratio));
        if (fw > 0) Draw.rrect(g, x + 8, y + 24, fw, 8, 4, ratio > 0.5f ? 0xFF55D26B : ratio > 0.25f ? 0xFFE6B94D : 0xFFFF3232);
    }
}
