package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;

/** Игроки рядом: ник, расстояние и стрелка направления. */
public class BetterNear extends HudModule {
    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};
    public final Setting.Num radius = add(new Setting.Num("Радиус, блоки", 100, 10, 300, 5));
    public final Setting.Num count = add(new Setting.Num("Максимум игроков", 5, 1, 10, 1));

    public BetterNear() { super("Better Near", "Игроки рядом с расстоянием", 1, 5); }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        List<Player> list = new ArrayList<>();
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            if (mc.player.distanceTo(p) <= radius.get()) list.add(p);
        }
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingDouble(p -> mc.player.distanceTo(p)));
        List<String[]> rows = new ArrayList<>();
        for (int i = 0; i < Math.min(list.size(), count.i()); i++) {
            Player p = list.get(i);
            double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
            double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            double diff = ((yaw - mc.player.getYRot()) % 360.0 + 540.0) % 360.0 - 180.0;
            int idx = (int) Math.floorMod(Math.round(diff / 45.0), 8L);
            rows.add(new String[]{p.getName().getString(), Math.round(mc.player.distanceTo(p)) + "m " + ARROWS[idx]});
        }
        Draw.panel(g, "Better Near", rows, posX.get(), posY.get());
    }
}
