package dev.vclient.module;

import dev.vclient.setting.Setting;

public abstract class HudModule extends Module {
    public final Setting.Num posX, posY;

    protected HudModule(String name, String desc, double x, double y) {
        super(name, Category.HUD);
        this.description = desc;
        posX = add(new Setting.Num("Позиция X, %", x, 0, 100, 1));
        posY = add(new Setting.Num("Позиция Y, %", y, 0, 100, 1));
    }
}
