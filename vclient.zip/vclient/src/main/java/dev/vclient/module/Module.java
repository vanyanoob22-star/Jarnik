package dev.vclient.module;

import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;

public abstract class Module {
    public enum Category { VISUALS, HUD, COMBAT, UTILITIES, SERVER, MARKERS }

    public final String name;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();
    public int key = -1;
    public boolean enabled;
    /** Включён только пока зажата клавиша (например зум). */
    public boolean hold;
    /** Одноразовое действие по нажатию (кнопки команд). */
    public boolean oneShot;
    /** onTick вызывается всегда, даже если модуль выключен (для одноразовых с состоянием). */
    public boolean tickAlways;
    /** Короткое описание для меню. */
    public String description = "";

    protected Module(String name, Category category) { this.name = name; this.category = category; }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean v) {
        if (oneShot) { if (v) onEnable(); return; }
        if (enabled == v) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onHud(GuiGraphicsExtractor g) {}
    public void onAttack(Entity e) {}
}
