package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Траектория брошенного предмета (перл, снежок, яйцо, зелья, пузырёк опыта). */
public class Predictions extends Module {
    public final Setting.Num ticks = add(new Setting.Num("Длина, тики", 100, 20, 200, 10));
    public final Setting.Bool marker = add(new Setting.Bool("Круг в точке падения", true));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));

    public Predictions() {
        super("Predictions", Category.VISUALS);
        description = "Траектории перлов и снарядов";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        ItemStack st = mc.player.getMainHandItem();
        double speed, grav;
        if (st.is(Items.ENDER_PEARL) || st.is(Items.SNOWBALL) || st.is(Items.EGG)) { speed = 1.5; grav = 0.03; }
        else if (st.is(Items.EXPERIENCE_BOTTLE)) { speed = 0.7; grav = 0.07; }
        else if (st.is(Items.SPLASH_POTION) || st.is(Items.LINGERING_POTION)) { speed = 0.5; grav = 0.05; }
        else return;

        float pt = VClient.partial;
        Vec3 prev = mc.player.getEyePosition(pt).add(0, -0.1, 0);
        Vec3 vel = mc.player.getViewVector(pt).scale(speed);
        int rgb = clientColor.get() ? 0xA64DFF : color.get();
        int c = Draw.alpha(rgb, 0xE0);
        Vec3 land = null;
        for (int i = 0; i < ticks.i(); i++) {
            Vec3 next = prev.add(vel);
            HitResult hr = mc.level.clip(new ClipContext(prev, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
            boolean hit = hr.getType() != HitResult.Type.MISS;
            if (hit) next = hr.getLocation();
            Projection.line(g, prev, next, 2, c);
            if (hit) { land = next; break; }
            prev = next;
            vel = vel.scale(0.99).add(0, -grav, 0);
        }
        if (land != null && marker.get()) Projection.ring(g, land.add(0, 0.05, 0), 0.4, 16, 2, Draw.alpha(rgb, 0xFF));
    }
}
