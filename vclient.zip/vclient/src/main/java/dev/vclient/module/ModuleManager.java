package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Projection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import org.lwjgl.glfw.GLFW;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();
    public final CustomCrosshair crosshair = new CustomCrosshair();
    public final Waypoints waypoints = new Waypoints();
    public final CustomHand customHand = new CustomHand();
    private final Map<Module, Boolean> wasDown = new HashMap<>();

    public ModuleManager() {
        // Визуалы
        modules.add(new Fullbright());
        modules.add(new Zoom());
        modules.add(crosshair);
        modules.add(customHand);
        modules.add(new TargetEsp());
        modules.add(new ChinaHat());
        modules.add(new JumpCircles());
        modules.add(new EntityBoxes());
        modules.add(new Predictions());

        // HUD
        modules.add(new Cooldowns());
        modules.add(new Potions());
        modules.add(new BetterNear());
        modules.add(new TargetHud());

        // Бой
        modules.add(new ArmorNotifier());
        modules.add(new HitSounds());
        modules.add(new HitTrails());
        modules.add(new RadiusPreview());

        // Утилиты
        modules.add(new AutoClicker());
        modules.add(new AutoCommand());
        modules.add(new ClickPearl());

        // Метки
        modules.add(waypoints);
        modules.add(new WaypointActions("Быстрая метка", "Метка там, куда смотришь", false));
        modules.add(new WaypointActions("Очистить метки", "Удалить все метки", true));

        // Сервер
        modules.add(new AutoSell("Автопродажа: рыба", "/sellfish"));
        modules.add(new AutoSell("Автопродажа: ферма", "/sellfarm"));
        modules.add(new AutoSell("Автопродажа: шахта", "/sellmine"));
        modules.add(new CommandBind("Sell All", "/sell all"));
        modules.add(new CommandBind("Sell Hand", "/sell hand"));
        modules.add(new CommandBind("Home", "/home"));
        modules.add(new CommandBind("Set Home", "/sethome"));
        modules.add(new CommandBind("Spawn", "/spawn"));
        modules.add(new CommandBind("RTP", "/rtp"));
        modules.add(new CommandBind("Kit", "/kit"));
        modules.add(new CommandBind("Repair All", "/repair all"));
        modules.add(new CommandBind("Heal", "/heal"));
        modules.add(new CommandBind("Feed", "/feed"));
    }

    public Module get(String name) {
        for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public void tick() {
        Minecraft mc = Minecraft.getInstance();
        boolean canPress = mc.gui.screen() == null && mc.player != null;
        long handle = mc.getWindow().handle();

        for (Module m : modules) {
            if (canPress && m.key > 0) {
                boolean down = GLFW.glfwGetKey(handle, m.key) == GLFW.GLFW_PRESS;
                boolean was = wasDown.getOrDefault(m, false);
                if (m.hold) {
                    m.setEnabled(down);
                } else if (down && !was) {
                    m.toggle();
                }
                wasDown.put(m, down);
            } else if (m.hold && m.enabled && mc.gui.screen() != null) {
                m.setEnabled(false);
            }
            if (m.enabled || m.tickAlways) m.onTick();
        }
    }

    public void renderHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Projection.update(VClient.partial);
        for (Module m : modules) if (m.enabled) m.onHud(g);
    }

    public void attacked(Entity e) {
        for (Module m : modules) if (m.enabled) m.onAttack(e);
    }
}
