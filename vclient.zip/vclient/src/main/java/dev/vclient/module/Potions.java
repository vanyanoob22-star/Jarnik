package dev.vclient.module;

import dev.vclient.gui.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;

public class Potions extends HudModule {
    public Potions() { super("Potions", "Активные эффекты и время", 1, 20); }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        List<String[]> rows = new ArrayList<>();
        for (MobEffectInstance e : mc.player.getActiveEffects()) {
            String name = e.getEffect().value().getDisplayName().getString();
            int amp = e.getAmplifier();
            if (amp > 0) name += " " + roman(amp + 1);
            String time;
            if (e.isInfiniteDuration()) time = "inf";
            else {
                int s = e.getDuration() / 20;
                time = (s / 60) + ":" + String.format("%02d", s % 60);
            }
            rows.add(new String[]{name, time});
        }
        if (!rows.isEmpty()) Draw.panel(g, "Potions", rows, posX.get(), posY.get());
    }

    private static String roman(int n) {
        return switch (n) { case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(n); };
    }
}
