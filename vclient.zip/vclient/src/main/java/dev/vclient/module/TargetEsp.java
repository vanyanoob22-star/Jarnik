package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Подсветка цели: кристаллы вокруг неё или кольцо. */
public class TargetEsp extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Режим", 0, "Кристаллы", "Кольцо"));
    public final Setting.Num count = add(new Setting.Num("Кол-во кристаллов", 12, 3, 32, 1));
    public final Setting.Num size = add(new Setting.Num("Размер", 0.09, 0.03, 0.3, 0.01));
    public final Setting.Num speed = add(new Setting.Num("Скорость", 1.0, 0.2, 4.0, 0.1));
    public final Setting.Num seconds = add(new Setting.Num("Показывать, сек", 6, 1, 20, 1));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));
    public final Setting.Bool react = add(new Setting.Bool("Реакция на урон", true));
    public final Setting.Color dmg = add(new Setting.Color("Цвет урона", 0xFF3232));

    public TargetEsp() {
        super("Target ESP", Category.VISUALS);
        description = "Подсветка текущей цели";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        LivingEntity t = VClient.lastTarget;
        if (t == null || !t.isAlive() || !Projection.ready) return;
        if (System.currentTimeMillis() - VClient.lastTargetTime > seconds.get() * 1000) return;
        float pt = VClient.partial;
        int rgb = clientColor.get() ? 0xA64DFF : color.get();
        if (react.get() && t.hurtTime > 0) rgb = dmg.get();
        double time = System.currentTimeMillis() / 1000.0 * speed.get();
        Vec3 base = t.getPosition(pt);

        if (mode.get() == 0) {
            Vec3 c = base.add(0, t.getBbHeight() / 2.0, 0);
            int n = count.i();
            double r = t.getBbWidth() + 0.4;
            for (int i = 0; i < n; i++) {
                double a = time + i * 2 * Math.PI / n;
                double y = Math.sin(time * 1.5 + i) * 0.4;
                Vec3 p = c.add(Math.cos(a) * r, y, Math.sin(a) * r);
                double[] s = Projection.project(p);
                if (s == null) continue;
                int core = Math.max(2, (int) (size.get() * Projection.pxPerBlock(s[2])));
                int glow = core * 2;
                int sx = (int) s[0], sy = (int) s[1];
                Draw.rrect(g, sx - glow / 2, sy - glow / 2, glow, glow, 3, Draw.alpha(rgb, 0x30));
                Draw.rrect(g, sx - core / 2, sy - core / 2, core, core, 2, Draw.alpha(rgb, 0xB0));
            }
        } else {
            double h = (Math.sin(time * 2) + 1) * 0.5 * t.getBbHeight();
            Projection.ring(g, base.add(0, 0.05 + h, 0), t.getBbWidth() * 0.7 + 0.2, 28, 2, Draw.alpha(rgb, 0xD0));
        }
    }
}
