package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;

public class AutoClicker extends Module {
    public final Setting.Num delay = add(new Setting.Num("Задержка (тики)", 10, 1, 20, 1));
    public final Setting.Mode button = add(new Setting.Mode("Кнопка мыши", 0, "Левая", "Правая"));
    public final Setting.Bool holdOnly = add(new Setting.Bool("Только при зажатой кнопке", true));
    private int ticks;

    public AutoClicker() {
        super("Auto Clicker", Category.UTILITIES);
        description = "Автокликер: левая бьёт цель под прицелом, правая использует предмет";
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.gui.screen() != null) return;
        KeyMapping km = button.get() == 0 ? mc.options.keyAttack : mc.options.keyUse;
        if (holdOnly.get() && !km.isDown()) { ticks = 0; return; }
        if (++ticks < delay.get()) return;
        ticks = 0;
        if (button.get() == 0) {
            if (mc.hitResult instanceof EntityHitResult ehr) {
                mc.gameMode.attack(mc.player, ehr.getEntity());
                mc.player.swing(InteractionHand.MAIN_HAND);
            }
        } else {
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }
}
