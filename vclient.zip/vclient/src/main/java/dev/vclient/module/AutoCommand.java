package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;

public class AutoCommand extends Module {
    public final Setting.Str commands = add(new Setting.Str("Команды (через запятую)", "/heal, /fix all"));
    public final Setting.Num interval = add(new Setting.Num("Интервал (сек)", 30, 1, 300, 1));
    private int ticks;

    public AutoCommand() {
        super("Auto Command", Category.UTILITIES);
        description = "Автоотправка команд с заданным интервалом";
    }

    @Override public void onEnable() { ticks = 0; }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) return;
        if (++ticks < interval.get() * 20) return;
        ticks = 0;
        for (String c : commands.get().split(",")) {
            c = c.trim();
            if (c.startsWith("/")) c = c.substring(1);
            if (!c.isEmpty()) mc.player.connection.sendCommand(c);
        }
    }
}
