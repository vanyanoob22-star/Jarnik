package dev.vclient.module;

import dev.vclient.gui.Draw;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Кулдауны предметов из инвентаря (перлы и всё, что сервер поставил на кулдаун). */
public class Cooldowns extends HudModule {
    private static class T { long t0; float p0; float total; }

    private final Map<Item, T> map = new HashMap<>();
    private final List<String[]> rows = new ArrayList<>();

    public Cooldowns() { super("Cooldowns", "Кулдауны предметов", 1, 35); }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        long now = mc.level.getGameTime();
        Set<Item> seen = new HashSet<>();
        rows.clear();
        var inv = mc.player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (st.isEmpty()) continue;
            Item it = st.getItem();
            if (!seen.add(it)) continue;
            float p = mc.player.getCooldowns().getCooldownPercent(st, 0f);
            if (p <= 0f) { map.remove(it); continue; }
            T t = map.get(it);
            if (t == null) { t = new T(); t.t0 = now; t.p0 = p; map.put(it, t); }
            if (now > t.t0 && p < t.p0) t.total = (now - t.t0) / (t.p0 - p);
            String rem = t.total > 0 ? String.format("%.1fs", p * t.total / 20f) : "...";
            rows.add(new String[]{st.getHoverName().getString(), rem});
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (!rows.isEmpty()) Draw.panel(g, "Cooldowns", rows, posX.get(), posY.get());
    }
}
