package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Рамки хитбоксов вокруг сущностей (видны сквозь стены). */
public class EntityBoxes extends Module {
    public final Setting.Mode targets = add(new Setting.Mode("Цели", 0, "Игроки", "Все существа"));
    public final Setting.Num radius = add(new Setting.Num("Дальность", 48, 8, 128, 4));
    public final Setting.Num thick = add(new Setting.Num("Толщина", 1, 1, 3, 1));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));

    public EntityBoxes() {
        super("Entity Boxes", Category.VISUALS);
        description = "Хитбоксы игроков и существ";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        int rgb = clientColor.get() ? 0xA64DFF : color.get();
        int c = Draw.alpha(rgb, 0xE0);
        if (targets.get() == 0) {
            for (Player p : mc.level.players()) draw(g, mc, p, c);
        } else {
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e instanceof LivingEntity) draw(g, mc, e, c);
            }
        }
    }

    private void draw(GuiGraphicsExtractor g, Minecraft mc, Entity e, int c) {
        if (e == mc.player || mc.player.distanceTo(e) > radius.get()) return;
        Vec3 off = e.getPosition(VClient.partial).subtract(e.position());
        AABB bb = e.getBoundingBox().move(off);
        Projection.box(g, bb, thick.i(), c);
    }
}
