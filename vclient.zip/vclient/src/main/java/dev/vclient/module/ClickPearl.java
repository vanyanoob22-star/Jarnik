package dev.vclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

/** Бросок перла из хотбара по одной клавише, затем возврат на прошлый слот. */
public class ClickPearl extends Module {
    public ClickPearl() {
        super("Click Pearl", Category.UTILITIES);
        oneShot = true;
        description = "Моментальный бросок перла по кнопке";
    }

    @Override public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) return;
        Inventory inv = mc.player.getInventory();
        int slot = -1;
        for (int i = 0; i < 9; i++) if (inv.getItem(i).is(Items.ENDER_PEARL)) { slot = i; break; }
        if (slot < 0) return;
        int prev = inv.getSelectedSlot();
        inv.setSelectedSlot(slot);
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        inv.setSelectedSlot(prev);
    }
}
