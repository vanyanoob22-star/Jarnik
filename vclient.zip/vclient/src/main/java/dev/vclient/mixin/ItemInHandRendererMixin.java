package dev.vclient.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.vclient.VClient;
import dev.vclient.module.CustomHand;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {

    private static CustomHand vclient$hand() {
        if (VClient.modules == null) return null;
        CustomHand h = VClient.modules.customHand;
        return h.enabled ? h : null;
    }

    /** Открываем отдельный уровень матрицы на время отрисовки руки. */
    @Inject(method = "submitArmWithItem", at = @At("HEAD"))
    private void vclient$push(AbstractClientPlayer player, float f, float x, InteractionHand hand, float swing,
                              ItemStack stack, float inv, PoseStack ps, SubmitNodeCollector c, int light, CallbackInfo ci) {
        ps.pushPose();
    }

    @Inject(method = "submitArmWithItem", at = @At("RETURN"))
    private void vclient$pop(AbstractClientPlayer player, float f, float x, InteractionHand hand, float swing,
                             ItemStack stack, float inv, PoseStack ps, SubmitNodeCollector c, int light, CallbackInfo ci) {
        ps.popPose();
    }

    /** Предмет в руке. */
    @Inject(method = "submitArmWithItem", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;I)V"))
    private void vclient$item(AbstractClientPlayer player, float f, float x, InteractionHand hand, float swing,
                              ItemStack stack, float inv, PoseStack ps, SubmitNodeCollector c, int light, CallbackInfo ci) {
        CustomHand h = vclient$hand();
        if (h != null && h.mode.get() != 1) h.apply(ps, hand, player);
    }

    /** Сама рука. */
    @Inject(method = "submitArmWithItem", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderPlayerArm(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;IFFLnet/minecraft/world/entity/HumanoidArm;)V"))
    private void vclient$arm(AbstractClientPlayer player, float f, float x, InteractionHand hand, float swing,
                             ItemStack stack, float inv, PoseStack ps, SubmitNodeCollector c, int light, CallbackInfo ci) {
        CustomHand h = vclient$hand();
        if (h == null) return;
        if (h.hide.get()) ps.scale(0f, 0f, 0f);
        else if (h.mode.get() != 2) h.apply(ps, hand, player);
    }

    /** Мгновенная смена предмета без анимации. */
    @Inject(method = "shouldInstantlyReplaceVisibleItem", at = @At("RETURN"), cancellable = true)
    private void vclient$skipSwap(CallbackInfoReturnable<Boolean> cir) {
        CustomHand h = vclient$hand();
        if (h != null && h.skipSwap.get()) cir.setReturnValue(true);
    }
}
