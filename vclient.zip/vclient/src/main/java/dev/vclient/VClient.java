package dev.vclient;

import dev.vclient.gui.MenuScreen;
import dev.vclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("vclient");
    public static ModuleManager modules;
    /** Последняя цель удара (для TargetHUD). */
    public static LivingEntity lastTarget;
    public static long lastTargetTime;
    /** Доля тика текущего кадра (для плавной отрисовки). */
    public static float partial;
    /** Клавиша меню: Right Shift. */
    public static final int MENU_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private boolean menuWasDown;

    @Override public void onInitializeClient() {
        modules = new ModuleManager();
        ConfigManager.load("default");

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean down = GLFW.glfwGetKey(mc.getWindow().handle(), MENU_KEY) == GLFW.GLFW_PRESS;
            if (down && !menuWasDown && mc.gui.screen() == null && mc.player != null) {
                mc.gui.setScreen(new MenuScreen());
            }
            menuWasDown = down;
            modules.tick();
        });

        // HUD-блоки
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("vclient", "hud"),
                (g, delta) -> {
                    partial = delta.getGameTimeDeltaPartialTick(false);
                    modules.renderHud(g);
                });

        // Свой прицел вместо ванильного, когда модуль включён
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (g, delta) -> {
            if (modules.crosshair.enabled) modules.crosshair.draw(g);
            else original.extractRenderState(g, delta);
        });

        // Удары по сущностям (TargetHUD, Hit Sounds)
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (level.isClientSide()) {
                if (entity instanceof LivingEntity le) { lastTarget = le; lastTargetTime = System.currentTimeMillis(); }
                modules.attacked(entity);
            }
            return InteractionResult.PASS;
        });

        LOG.info("VClient loaded");
    }
}
