package dev.vclient.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public abstract class Setting<T> {
    public final String name;
    protected T value;

    protected Setting(String name, T def) { this.name = name; this.value = def; }

    public T get() { return value; }
    public void set(T v) { this.value = v; }
    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);
    public abstract String display();

    public static class Bool extends Setting<Boolean> {
        public Bool(String n, boolean d) { super(n, d); }
        public void toggle() { value = !value; }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) { value = e.getAsBoolean(); }
        public String display() { return value ? "ON" : "OFF"; }
    }

    public static class Num extends Setting<Double> {
        public final double min, max, step;
        public Num(String n, double d, double min, double max, double step) {
            super(n, d); this.min = min; this.max = max; this.step = step;
        }
        public void add(int dir) { value = Math.max(min, Math.min(max, Math.round((value + dir * step) / step) * step)); }
        public float f() { return value.floatValue(); }
        public int i() { return (int) Math.round(value); }
        public double frac() { return (value - min) / (max - min); }
        public void setFrom(double t) {
            t = Math.max(0, Math.min(1, t));
            double v = min + t * (max - min);
            value = Math.max(min, Math.min(max, Math.round(v / step) * step));
        }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) { value = Math.max(min, Math.min(max, e.getAsDouble())); }
        public String display() { return step >= 1 ? String.valueOf(Math.round(value)) : String.format("%.2f", value); }
    }

    public static class Str extends Setting<String> {
        public Str(String n, String d) { super(n, d); }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) { value = e.getAsString(); }
        public String display() { return value; }
    }

    /** Выпадающий список (один вариант). */
    public static class Mode extends Setting<Integer> {
        public final List<String> options;
        public Mode(String n, int def, String... o) { super(n, def); options = List.of(o); }
        public String current() { return options.get(value); }
        public void setIndex(int i) { value = Math.max(0, Math.min(options.size() - 1, i)); }
        public JsonElement toJson() { return new JsonPrimitive(current()); }
        public void fromJson(JsonElement e) { int i = options.indexOf(e.getAsString()); if (i >= 0) value = i; }
        public String display() { return current(); }
    }

    /** Список с несколькими вариантами. */
    public static class Multi extends Setting<Set<String>> {
        public final List<String> options;
        public Multi(String n, String... o) { super(n, new LinkedHashSet<>()); options = List.of(o); }
        public boolean has(String o) { return value.contains(o); }
        public void toggle(String o) { if (!value.remove(o)) value.add(o); }
        public JsonElement toJson() { JsonArray a = new JsonArray(); for (String s : value) a.add(s); return a; }
        public void fromJson(JsonElement e) {
            value.clear();
            for (JsonElement x : e.getAsJsonArray()) if (options.contains(x.getAsString())) value.add(x.getAsString());
        }
        public String display() { return value.isEmpty() ? "Ничего" : String.join(", ", value); }
    }

    /** Цвет RGB, вводится как hex. */
    public static class Color extends Setting<Integer> {
        public Color(String n, int rgb) { super(n, rgb & 0xFFFFFF); }
        public String hex() { return String.format("#%06X", value & 0xFFFFFF); }
        public void setHex(String s) {
            try { value = Integer.parseInt(s.replace("#", ""), 16) & 0xFFFFFF; } catch (Exception ignored) { }
        }
        public int argb() { return 0xFF000000 | value; }
        public JsonElement toJson() { return new JsonPrimitive(hex()); }
        public void fromJson(JsonElement e) { setHex(e.getAsString()); }
        public String display() { return hex(); }
    }
}
