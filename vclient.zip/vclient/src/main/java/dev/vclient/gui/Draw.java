package dev.vclient.gui;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class Draw {
    public static final int ACCENT = 0xFFA64DFF;

    private Draw() {}

    public static int alpha(int rgb, int a) { return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF); }

    public static void rrect(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, c); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int in = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - i - 1, x + w - in, y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    public static void rrectLeft(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int c) {
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int in = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            g.fill(x + in, y + i, x + w, y + i + 1, c);
            g.fill(x + in, y + h - i - 1, x + w, y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    /** HUD-блок: заголовок и строки «слева / справа». Позиция в процентах экрана. */
    public static void panel(GuiGraphicsExtractor g, String title, List<String[]> rows, double xp, double yp) {
        Minecraft mc = Minecraft.getInstance();
        Font f = mc.font;
        int w = Math.max(120, f.width(title) + 34);
        for (String[] r : rows) w = Math.max(w, f.width(r[0]) + f.width(r[1]) + 34);
        int h = 24 + rows.size() * 13 + 4;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        int x = (int) ((sw - w) * xp / 100.0), y = (int) ((sh - h) * yp / 100.0);
        rrect(g, x, y, w, h, 6, 0xC8101015);
        rrect(g, x + 8, y + 8, 6, 6, 3, ACCENT);
        g.text(f, title, x + 19, y + 7, 0xFFFFFFFF);
        int ry = y + 22;
        for (String[] r : rows) {
            g.text(f, r[0], x + 8, ry, 0xFFC8C8D0);
            g.text(f, r[1], x + w - 8 - f.width(r[1]), ry, 0xFFFFFFFF);
            ry += 13;
        }
    }
}
