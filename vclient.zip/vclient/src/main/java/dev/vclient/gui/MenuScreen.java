package dev.vclient.gui;

import dev.vclient.ConfigManager;
import dev.vclient.VClient;
import dev.vclient.module.Module;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import static dev.vclient.gui.Draw.rrect;
import static dev.vclient.gui.Draw.rrectLeft;

/** Меню «Огурец Клиент»: тёмная полупрозрачная панель, вкладки слева, карточки модулей. */
public class MenuScreen extends Screen {
    private static final Identifier LOGO = Identifier.fromNamespaceAndPath("vclient", "textures/gui/logo.png");
    private static final int LOGO_W = 420, LOGO_H = 213;

    private static final int SW = 112;
    private static final int BG = 0xC8101015, SIDE = 0x50000000, CARD = 0x90222230, FIELD = 0xB0090910;
    private static final int OPT = 0x30FFFFFF;
    private static final int ACCENT = 0xFFA64DFF, ACCENT_DIM = 0xFF6F2FB5, OFF = 0xFF3A3A46;
    private static final int TXT = 0xFFFFFFFF, SUB = 0xFF9A9AAA;
    private static final String[] TABS = {"Визуалы", "HUD", "Бой", "Утилиты", "Сервер", "Метки", "Конфиги"};
    private static final int CFG_TAB = 6;

    private record Hit(int x, int y, int w, int h, boolean clip, DoubleConsumer click, boolean draggable) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private final List<Module> expanded = new ArrayList<>();
    private int tab = 0;
    private float scroll = 0;
    private int contentH = 0;
    private int cx, cy, cw, ch;
    private Module binding;
    private Setting.Str focusStr;
    private Setting.Color focusColor;
    private String hexBuf = "";
    private Setting<?> openList;
    private boolean focusSearch, focusCfg;
    private String search = "";
    private String cfgName = "default";
    private String cfgMsg = "";
    private DoubleConsumer dragging;

    public MenuScreen() { super(Component.literal("Огурец Клиент")); }

    @Override public boolean isPauseScreen() { return false; }

    private void hit(int x, int y, int w, int h, boolean clip, DoubleConsumer c) { hits.add(new Hit(x, y, w, h, clip, c, false)); }
    private void dragHit(int x, int y, int w, int h, DoubleConsumer c) { hits.add(new Hit(x, y, w, h, true, c, true)); }
    private void t(GuiGraphicsExtractor g, String s, int x, int y, int color) { g.text(font, s, x, y, color); }

    private static void sw(GuiGraphicsExtractor g, int x, int y, boolean on) {
        rrect(g, x, y, 24, 12, 6, on ? ACCENT : OFF);
        rrect(g, x + (on ? 14 : 2), y + 2, 8, 8, 4, 0xFFFFFFFF);
    }

    private List<Module> visible() {
        List<Module> out = new ArrayList<>();
        String q = search.toLowerCase();
        for (Module m : VClient.modules.modules) {
            if (!q.isEmpty()) {
                if (m.name.toLowerCase().contains(q) || m.description.toLowerCase().contains(q)) out.add(m);
            } else if (tab < CFG_TAB && m.category == Module.Category.values()[tab]) out.add(m);
        }
        return out;
    }

    private int rowH(Setting<?> s) {
        if (s instanceof Setting.Num) return 26;
        if (s instanceof Setting.Str) return 28;
        if (s instanceof Setting.Color) return 22;
        if (s instanceof Setting.Mode md) return 30 + (openList == s ? md.options.size() * 16 + 2 : 0);
        if (s instanceof Setting.Multi mu) return 30 + (openList == s ? mu.options.size() * 16 + 2 : 0);
        return 18;
    }

    private int cardHeight(Module m) {
        if (!expanded.contains(m)) return 36;
        int h = 36 + 4;
        for (Setting<?> s : m.settings) h += rowH(s);
        return h + 22;
    }

    // ---------- основной рендер ----------
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        hits.clear();
        int pw = Math.min(width - 30, 580), ph = Math.min(height - 30, 340);
        int x0 = (width - pw) / 2, y0 = (height - ph) / 2;

        g.fill(0, 0, width, height, 0x66000000);
        rrect(g, x0, y0, pw, ph, 8, BG);
        rrectLeft(g, x0, y0, SW, ph, 8, SIDE);

        int lw = SW - 24, lh = lw * LOGO_H / LOGO_W;
        g.blit(RenderPipelines.GUI_TEXTURED, LOGO, x0 + 12, y0 + 12, 0f, 0f, lw, lh, LOGO_W, LOGO_H, LOGO_W, LOGO_H);

        int ty = y0 + 12 + lh + 16;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            boolean sel = tab == i && search.isEmpty();
            if (sel) rrect(g, x0 + 8, ty, SW - 16, 20, 6, ACCENT);
            t(g, TABS[i], x0 + 18, ty + 6, sel ? TXT : SUB);
            hit(x0 + 8, ty, SW - 16, 20, false, v -> { tab = idx; scroll = 0; search = ""; openList = null; });
            ty += 24;
        }

        t(g, search.isEmpty() ? TABS[tab] : "Поиск", x0 + SW + 14, y0 + 12, TXT);
        int sfw = 130, sfx = x0 + pw - sfw - 12, sfy = y0 + 7;
        rrect(g, sfx, sfy, sfw, 18, 5, FIELD);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        if (search.isEmpty() && !focusSearch) t(g, "Поиск", sfx + 6, sfy + 5, SUB);
        else t(g, font.plainSubstrByWidth(search, sfw - 14, true) + (focusSearch && blink ? "_" : ""), sfx + 6, sfy + 5, TXT);
        hit(sfx, sfy, sfw, 18, false, v -> focusSearch = true);

        cx = x0 + SW + 10; cy = y0 + 34; cw = pw - SW - 20; ch = ph - 34 - 10;
        int maxScroll = Math.max(0, contentH - ch);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        g.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        if (tab == CFG_TAB && search.isEmpty()) drawConfigs(g);
        else drawCards(g);
        g.disableScissor();

        if (maxScroll > 0) {
            int bh = Math.max(16, ch * ch / contentH);
            int by = cy + (int) ((ch - bh) * (scroll / maxScroll));
            rrect(g, x0 + pw - 6, by, 3, bh, 1, ACCENT);
        }
    }

    private void drawCards(GuiGraphicsExtractor g) {
        int colW = (cw - 8) / 2;
        int[] colY = {0, 0};
        for (Module m : visible()) {
            int col = colY[0] <= colY[1] ? 0 : 1;
            int h = cardHeight(m);
            int px = cx + col * (colW + 8), py = cy + colY[col] - (int) scroll;
            drawCard(g, m, px, py, colW, h);
            colY[col] += h + 8;
        }
        contentH = Math.max(colY[0], colY[1]);
    }

    private void drawCard(GuiGraphicsExtractor g, Module m, int px, int py, int w, int h) {
        boolean open = expanded.contains(m);
        boolean bl = (System.currentTimeMillis() / 500) % 2 == 0;
        rrect(g, px, py, w, h, 6, CARD);
        t(g, m.name, px + 10, py + 8, TXT);
        t(g, font.plainSubstrByWidth(m.description, w - 80), px + 10, py + 21, SUB);
        t(g, open ? "^" : "v", px + w - 14, py + 13, SUB);
        hit(px, py, w, 36, true, v -> { if (!expanded.remove(m)) expanded.add(m); });

        if (m.oneShot) {
            rrect(g, px + w - 76, py + 10, 52, 16, 5, ACCENT_DIM);
            t(g, "Запуск", px + w - 76 + (52 - font.width("Запуск")) / 2, py + 14, TXT);
            hit(px + w - 76, py + 10, 52, 16, true, v -> m.setEnabled(true));
        } else {
            sw(g, px + w - 52, py + 12, m.enabled);
            hit(px + w - 54, py + 8, 28, 20, true, v -> m.toggle());
        }
        if (!open) return;

        int sy = py + 40;
        for (Setting<?> s : m.settings) {
            int fx = px + 10, fw = w - 20;
            if (s instanceof Setting.Bool b) {
                t(g, b.name, px + 10, sy + 4, SUB);
                sw(g, px + w - 34, sy + 3, b.get());
                hit(px + w - 36, sy, 28, 16, true, v -> b.toggle());
            } else if (s instanceof Setting.Num n) {
                t(g, n.name, px + 10, sy + 2, SUB);
                String val = n.display();
                t(g, val, px + w - 10 - font.width(val), sy + 2, TXT);
                int tx = px + 10, tw = w - 20, ty2 = sy + 16;
                rrect(g, tx, ty2, tw, 4, 2, OFF);
                int fill = (int) (tw * n.frac());
                if (fill > 0) rrect(g, tx, ty2, fill, 4, 2, ACCENT);
                rrect(g, tx + fill - 4, ty2 - 2, 8, 8, 4, 0xFFFFFFFF);
                dragHit(tx - 4, ty2 - 6, tw + 8, 16, v -> n.setFrom((v - tx) / tw));
            } else if (s instanceof Setting.Str st) {
                t(g, st.name, px + 10, sy + 1, SUB);
                int fy = sy + 12;
                rrect(g, fx, fy, fw, 14, 3, FIELD);
                boolean foc = focusStr == st;
                t(g, font.plainSubstrByWidth(st.get(), fw - 10, true) + (foc && bl ? "_" : ""), fx + 4, fy + 3, TXT);
                hit(fx, fy, fw, 14, true, v -> focusStr = st);
            } else if (s instanceof Setting.Color c) {
                t(g, c.name, px + 10, sy + 5, SUB);
                int bx = px + w - 86;
                rrect(g, bx, sy + 2, 76, 14, 3, FIELD);
                rrect(g, bx + 4, sy + 5, 8, 8, 4, c.argb());
                boolean foc = focusColor == c;
                String hx = foc ? hexBuf : c.hex().substring(1);
                t(g, "#" + hx + (foc && bl ? "_" : ""), bx + 16, sy + 5, TXT);
                hit(bx, sy + 2, 76, 14, true, v -> { focusColor = c; hexBuf = c.hex().substring(1); });
            } else if (s instanceof Setting.Mode md) {
                t(g, md.name, px + 10, sy + 1, SUB);
                int fy = sy + 12;
                rrect(g, fx, fy, fw, 14, 3, FIELD);
                t(g, md.current(), fx + 4, fy + 3, TXT);
                t(g, openList == md ? "^" : "v", fx + fw - 10, fy + 3, SUB);
                hit(fx, fy, fw, 14, true, v -> openList = openList == md ? null : md);
                if (openList == md) {
                    int oy = fy + 16;
                    for (int i = 0; i < md.options.size(); i++) {
                        final int idx = i;
                        boolean sel = md.get() == i;
                        rrect(g, fx, oy, fw, 14, 3, sel ? ACCENT : OPT);
                        t(g, md.options.get(i), fx + 6, oy + 3, TXT);
                        hit(fx, oy, fw, 14, true, v -> { md.setIndex(idx); openList = null; });
                        oy += 16;
                    }
                }
            } else if (s instanceof Setting.Multi mu) {
                t(g, mu.name, px + 10, sy + 1, SUB);
                int fy = sy + 12;
                rrect(g, fx, fy, fw, 14, 3, FIELD);
                t(g, font.plainSubstrByWidth(mu.display(), fw - 20), fx + 4, fy + 3, TXT);
                t(g, openList == mu ? "^" : "v", fx + fw - 10, fy + 3, SUB);
                hit(fx, fy, fw, 14, true, v -> openList = openList == mu ? null : mu);
                if (openList == mu) {
                    int oy = fy + 16;
                    for (String o : mu.options) {
                        boolean sel = mu.has(o);
                        rrect(g, fx, oy, fw, 14, 3, sel ? ACCENT : OPT);
                        t(g, o, fx + 6, oy + 3, TXT);
                        hit(fx, oy, fw, 14, true, v -> mu.toggle(o));
                        oy += 16;
                    }
                }
            }
            sy += rowH(s);
        }
        t(g, "Клавиша", px + 10, sy + 5, SUB);
        String kn = binding == m ? "..." : (m.key > 0 ? keyName(m.key) : "нет");
        rrect(g, px + w - 70, sy + 2, 60, 14, 4, FIELD);
        t(g, kn, px + w - 70 + (60 - font.width(kn)) / 2, sy + 5, TXT);
        hit(px + w - 70, sy + 2, 60, 14, true, v -> binding = m);
    }

    private void drawConfigs(GuiGraphicsExtractor g) {
        List<String> names = ConfigManager.list();
        int rows = Math.min(names.size(), 6);
        int h = 100 + rows * 16;
        int px = cx, py = cy - (int) scroll;
        rrect(g, px, py, cw, h, 6, CARD);
        t(g, "Конфиги", px + 10, py + 8, TXT);
        t(g, "Файл лежит в config/vclient/<имя>.json, его можно отправить другу", px + 10, py + 21, SUB);

        t(g, "Имя конфига", px + 10, py + 38, SUB);
        int fx = px + 10, fy = py + 49, fw = cw - 20;
        rrect(g, fx, fy, fw, 14, 3, FIELD);
        boolean bl = (System.currentTimeMillis() / 500) % 2 == 0;
        t(g, cfgName + (focusCfg && bl ? "_" : ""), fx + 4, fy + 3, TXT);
        hit(fx, fy, fw, 14, true, v -> focusCfg = true);

        int by = py + 70;
        rrect(g, px + 10, by, 80, 16, 5, ACCENT_DIM);
        t(g, "Сохранить", px + 10 + (80 - font.width("Сохранить")) / 2, by + 4, TXT);
        hit(px + 10, by, 80, 16, true, v -> { if (!cfgName.isEmpty()) { ConfigManager.save(cfgName); cfgMsg = "Сохранено: " + cfgName; } });
        rrect(g, px + 98, by, 80, 16, 5, ACCENT_DIM);
        t(g, "Загрузить", px + 98 + (80 - font.width("Загрузить")) / 2, by + 4, TXT);
        hit(px + 98, by, 80, 16, true, v -> cfgMsg = ConfigManager.load(cfgName) ? "Загружено: " + cfgName : "Нет такого конфига: " + cfgName);
        t(g, cfgMsg, px + 186, by + 4, SUB);

        int ly = py + 94;
        for (int i = 0; i < rows; i++) {
            final String n = names.get(i);
            t(g, "- " + n, px + 14, ly + 2, n.equals(cfgName) ? ACCENT : TXT);
            hit(px + 10, ly, cw - 20, 14, true, v -> cfgName = n);
            ly += 16;
        }
        contentH = h;
    }

    // ---------- ввод ----------
    private boolean inContent(double mx, double my) { return mx >= cx && mx < cx + cw && my >= cy && my < cy + ch; }

    private void clearInputFocus() {
        focusStr = null; focusColor = null; focusSearch = false; focusCfg = false; binding = null;
    }

    private boolean typing() { return focusStr != null || focusColor != null || focusSearch || focusCfg; }

    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.in(mx, my)) continue;
            if (h.clip() && !inContent(mx, my)) continue;
            clearInputFocus();
            h.click().accept(mx);
            if (h.draggable()) dragging = h.click();
            return true;
        }
        clearInputFocus();
        return true;
    }

    @Override public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging != null) { dragging.accept(e.x()); return true; }
        return super.mouseDragged(e, dx, dy);
    }

    @Override public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (float) (sy * 20);
        return true;
    }

    @Override public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (binding != null) {
            binding.key = k == GLFW.GLFW_KEY_ESCAPE ? -1 : k;
            binding = null;
            return true;
        }
        if (typing()) {
            if (k == GLFW.GLFW_KEY_BACKSPACE) {
                if (focusStr != null) { String s = focusStr.get(); if (!s.isEmpty()) focusStr.set(s.substring(0, s.length() - 1)); }
                else if (focusColor != null) { if (!hexBuf.isEmpty()) hexBuf = hexBuf.substring(0, hexBuf.length() - 1); }
                else if (focusSearch) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); scroll = 0; }
                else if (!cfgName.isEmpty()) cfgName = cfgName.substring(0, cfgName.length() - 1);
            } else if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_KP_ENTER) {
                clearInputFocus();
            }
            return true;
        }
        return super.keyPressed(e);
    }

    @Override public boolean charTyped(CharacterEvent e) {
        int cp = e.codepoint();
        if (cp < 32 || cp == 127) return false;
        String s = new String(Character.toChars(cp));
        if (focusStr != null) { focusStr.set(focusStr.get() + s); return true; }
        if (focusColor != null) {
            if (hexBuf.length() < 6 && s.matches("[0-9A-Fa-f]")) {
                hexBuf += s.toUpperCase();
                if (hexBuf.length() == 6) focusColor.setHex(hexBuf);
            }
            return true;
        }
        if (focusSearch) { search += s; scroll = 0; return true; }
        if (focusCfg) { if (s.matches("[A-Za-z0-9_\\-]")) cfgName += s; return true; }
        return false;
    }

    @Override public void onClose() {
        ConfigManager.save("default");
        super.onClose();
    }

    private static String keyName(int key) {
        String n = GLFW.glfwGetKeyName(key, 0);
        if (n != null) return n.toUpperCase();
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_INSERT -> "INSERT";
            case GLFW.GLFW_KEY_DELETE -> "DELETE";
            case GLFW.GLFW_KEY_HOME -> "HOME";
            case GLFW.GLFW_KEY_END -> "END";
            case GLFW.GLFW_KEY_PAGE_UP -> "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN -> "PGDN";
            default -> "K" + key;
        };
    }
}
