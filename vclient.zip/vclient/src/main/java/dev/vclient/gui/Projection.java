package dev.vclient.gui;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Проекция мировых координат на экран (рисуем поверх HUD). Точно в первом лице, приблизительно в третьем. */
public final class Projection {
    private static double ex, ey, ez, fx, fy, fz, rx, ry, rz, ux, uy, uz, tanHalf, aspect;
    public static int sw, sh;
    public static boolean ready;
    private static final double NEAR = 0.05;

    private Projection() {}

    public static void update(float partial) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        ready = false;
        if (p == null) return;
        Vec3 eye = p.getEyePosition(partial);
        float yaw = p.getViewYRot(partial), pitch = p.getViewXRot(partial);
        CameraType ct = mc.options.getCameraType();
        boolean first = ct.isFirstPerson();
        if (ct == CameraType.THIRD_PERSON_FRONT) { yaw += 180f; pitch = -pitch; }
        double y = Math.toRadians(yaw), pt = Math.toRadians(pitch);
        fx = -Math.sin(y) * Math.cos(pt);
        fy = -Math.sin(pt);
        fz = Math.cos(y) * Math.cos(pt);
        rx = -Math.cos(y); ry = 0; rz = -Math.sin(y);
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;
        double dist = first ? 0 : 4.0;
        ex = eye.x - fx * dist; ey = eye.y - fy * dist; ez = eye.z - fz * dist;
        sw = mc.getWindow().getGuiScaledWidth();
        sh = mc.getWindow().getGuiScaledHeight();
        aspect = (double) sw / Math.max(1, sh);
        tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        ready = true;
    }

    public static double depth(double x, double y, double z) {
        return (x - ex) * fx + (y - ey) * fy + (z - ez) * fz;
    }

    /** {экранX, экранY, глубина} или null, если точка за камерой. */
    public static double[] project(double x, double y, double z) {
        double dx = x - ex, dy = y - ey, dz = z - ez;
        double cz = dx * fx + dy * fy + dz * fz;
        if (cz < NEAR) return null;
        double cx = dx * rx + dy * ry + dz * rz;
        double cy = dx * ux + dy * uy + dz * uz;
        double sx = sw / 2.0 * (1 + cx / (cz * tanHalf * aspect));
        double sy = sh / 2.0 * (1 - cy / (cz * tanHalf));
        return new double[]{sx, sy, cz};
    }

    public static double[] project(Vec3 v) { return project(v.x, v.y, v.z); }

    /** Сколько пикселей занимает 1 блок на данной глубине. */
    public static double pxPerBlock(double depth) { return (sh / 2.0) / (tanHalf * depth); }

    public static void line(GuiGraphicsExtractor g, Vec3 a, Vec3 b, int th, int argb) {
        double az = depth(a.x, a.y, a.z), bz = depth(b.x, b.y, b.z);
        if (az < NEAR && bz < NEAR) return;
        Vec3 pa = a, pb = b;
        if (az < NEAR) { double t = (NEAR - az) / (bz - az); pa = a.add(b.subtract(a).scale(t)); }
        else if (bz < NEAR) { double t = (NEAR - bz) / (az - bz); pb = b.add(a.subtract(b).scale(t)); }
        double[] s1 = project(pa), s2 = project(pb);
        if (s1 == null || s2 == null) return;
        line2d(g, s1[0], s1[1], s2[0], s2[1], th, argb);
    }

    private static void line2d(GuiGraphicsExtractor g, double x1, double y1, double x2, double y2, int th, int c) {
        if ((x1 < -50 && x2 < -50) || (y1 < -50 && y2 < -50) || (x1 > sw + 50 && x2 > sw + 50) || (y1 > sh + 50 && y2 > sh + 50)) return;
        double dx = x2 - x1, dy = y2 - y1;
        double len = Math.max(Math.abs(dx), Math.abs(dy));
        double step = Math.max(1, th);
        int n = (int) Math.min(900, len / step);
        if (n < 1) { dot(g, x1, y1, th, c); return; }
        for (int i = 0; i <= n; i++) {
            double t = (double) i / n;
            dot(g, x1 + dx * t, y1 + dy * t, th, c);
        }
    }

    private static void dot(GuiGraphicsExtractor g, double x, double y, int th, int c) {
        int ix = (int) Math.round(x) - th / 2, iy = (int) Math.round(y) - th / 2;
        g.fill(ix, iy, ix + th, iy + th, c);
    }

    public static void ring(GuiGraphicsExtractor g, Vec3 center, double radius, int segs, int th, int argb) {
        Vec3 prev = null;
        for (int i = 0; i <= segs; i++) {
            double a = i * 2 * Math.PI / segs;
            Vec3 cur = center.add(Math.cos(a) * radius, 0, Math.sin(a) * radius);
            if (prev != null) line(g, prev, cur, th, argb);
            prev = cur;
        }
    }

    public static void box(GuiGraphicsExtractor g, AABB b, int th, int argb) {
        Vec3[] c = {
            new Vec3(b.minX, b.minY, b.minZ), new Vec3(b.maxX, b.minY, b.minZ),
            new Vec3(b.maxX, b.minY, b.maxZ), new Vec3(b.minX, b.minY, b.maxZ),
            new Vec3(b.minX, b.maxY, b.minZ), new Vec3(b.maxX, b.maxY, b.minZ),
            new Vec3(b.maxX, b.maxY, b.maxZ), new Vec3(b.minX, b.maxY, b.maxZ)
        };
        int[][] e = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for (int[] ed : e) line(g, c[ed[0]], c[ed[1]], th, argb);
    }
}
